def add(*args):
    ''' Add the given variables together.
    '''
    return sum(args)
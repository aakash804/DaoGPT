import math

def multiply(*args):
    ''' Multiply the given variables together.
    '''
    return math.prod(args)
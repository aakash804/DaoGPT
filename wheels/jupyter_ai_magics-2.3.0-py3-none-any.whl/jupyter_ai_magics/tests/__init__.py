"""Python unit tests for jupyter_ai_magics."""

def not_(value):
    ''' Negate the given value.
    '''
    return not value